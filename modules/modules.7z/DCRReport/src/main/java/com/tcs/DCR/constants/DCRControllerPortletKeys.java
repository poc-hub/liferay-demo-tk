package com.tcs.DCR.constants;

/**
 * @author MADDY
 */
public class DCRControllerPortletKeys {

	public static final String DCRCONTROLLER =
		"com_tcs_DCR_DCRControllerPortlet";

}