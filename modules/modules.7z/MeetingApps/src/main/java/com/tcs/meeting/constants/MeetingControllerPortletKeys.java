package com.tcs.meeting.constants;

/**
 * @author MADDY
 */
public class MeetingControllerPortletKeys {

	public static final String MEETINGCONTROLLER =
		"com_tcs_meeting_MeetingControllerPortlet";

}